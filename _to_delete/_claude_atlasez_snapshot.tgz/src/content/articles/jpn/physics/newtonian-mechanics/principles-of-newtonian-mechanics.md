---
articleId: ja-physics-principles-of-newtonian-mechanics
locale: ja
title: ニュートン力学の原理
slug: principles-of-newtonian-mechanics
subject: physics
category: newtonian-mechanics
concepts:
  - id: physics.newtonian-mechanics.principles-of-newtonian-mechanics
authors:
  - atlas-physics-team
reviewers: []
status: published
createdAt: 2024-01-01
updatedAt: 2026-07-22
summary: ここでは、ニュートン力学の原理を置く。
difficulty: intermediate
estimatedMinutes: 15
tags:
  - ニュートン力学の原理
aliases: []
exerciseIds:
  pre: []
  post: []
references: []
---

ここでは、ニュートン力学の原理を置く。当然、ニュートン力学における基本的な実験事実や経験法則と整合的な原理が採用されるが、ニュートン力学における全てのことは、その基本的な実験事実や経験法則も含めて、全て以下の原理から導かれるべきものである。

ニュートン力学の原理は、空間と時間・系・力に関する大きく3つの原理からなる。まずは原理を提示し、その後それぞれの意味について簡単に解説する。

## I. 空間と時間

### I-i. 空間と時間の定義

空間は、一様かつ平坦で単連結な3次元リーマン多様体である。時間は、一様で連結な向きづけられた1次元リーマン多様体である。

## II. 系

### II-i. 質点と質点系

質点は質点の運動$\boldsymbol{r}(t)$、慣性質量$m_\mathrm{I}$、チャージ(荷)$q$(チャージは1つとは限らない)の組である。慣性質量とチャージは時刻・質点の位置・座標系によらない量である。チャージはその単位を定めれば具体的な値の表現が一意に定まる。質点系は1つ以上の質点の組である。

### II-ii. 系の定義

系は観測者、質点系、力を与える場(場は1つとは限らない)の組である。

### II-iii. 部分系の存在

ある質点系の部分的な質点系をその他の部分との空間的な共通部分がないように任意に選んだとき、それに対して元の系と同じ運動を再現する場からなる系(部分系)が存在する。

## III. 力

### III-i. 力の定義

ある質点に働く力$\boldsymbol{F}$はその質点の慣性質量$m_\mathrm{I}$とその質点の加速度$\boldsymbol{a}$の積である。すなわち、$m_\mathrm{I}\boldsymbol{a}=\boldsymbol{F}$。

### III-ii. 運動方程式

系・力の関数形・境界条件(初期位置と初期速度、あるいはそれと同じ自由度を持つもの)を与えれば、それが特異点を生じるような条件でない限り、$\boldsymbol{r}(t)$に関する微分方程式$m_\mathrm{I}\boldsymbol{a}=\boldsymbol{F}$の解が一意に存在する。

## 解説

「I. 空間と時間」は、質点系や場の舞台である空間と時間を定義するものである。特にその性質を具体的に規定することでこれらの構造を定める原理である。

「II. 系」は、物理的な対象としての系を定義するものである。何によって構成されるかに加えて、どのような性質を持つべきかをも明示的に定める原理である。

「III. 力」は、運動の原因としての力を定義するものである。物体の運動の原因として力を想定し、物体の運動から力の具体形を調べ、逆に物体に働く力の具体形を与えたときの物体の運動を知るという力学の営みの中心的役割を果たす原理である。
